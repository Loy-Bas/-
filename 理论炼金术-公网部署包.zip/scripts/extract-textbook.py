"""Read the user-supplied PDF; keep its full extracted text local and untracked."""
from pathlib import Path
import hashlib,json,re,sys
import pymupdf
source=Path(sys.argv[1]);root=Path(__file__).resolve().parents[1]
out=root/'research';out.mkdir(exist_ok=True)
doc=pymupdf.open(source)
pages=[]
for i,page in enumerate(doc):
    text=page.get_text(sort=True)
    pages.append({'pdfPage':i+1,'text':text})
(out/'pages.json').write_text(json.dumps(pages,ensure_ascii=False),encoding='utf-8')
(out/'textbook.txt').write_text('\n\n'.join(f'===== PDF {p["pdfPage"]} =====\n{p["text"]}' for p in pages),encoding='utf-8')
for i in [0,6,11,12,27,39,283]:
    if i<len(doc):doc[i].get_pixmap(matrix=pymupdf.Matrix(1,1)).save(out/f'page-{i+1:03}.png')
(out/'source.json').write_text(json.dumps({'name':source.name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'pdfPages':len(doc),'path':str(source)},ensure_ascii=False,indent=2),encoding='utf-8')
print('Extracted',len(pages),'pages; total characters:',sum(len(p['text']) for p in pages))
