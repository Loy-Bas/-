import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const root=new URL('../',import.meta.url),read=p=>readFile(new URL(p,root),'utf8');
let html=await read('src/index.html');
const css=await read('src/style.css');
const files=['textbook-meta.js','extra-content.js','content.js','engine.js','review-questions.js'];
const flatten=s=>s.replace(/^import .*;\r?\n/gm,'').replace(/\bexport (?=(?:const|function|async function)\b)/g,'');
const shared=(await Promise.all(files.map(f=>read('src/'+f)))).map(flatten).join('\n');
const retrieval=flatten(await read('worker/retrieval.js'));
const corpus=JSON.parse(await read('data/textbook-index.json'));
const offlineApi=`
const offlineCorpus=${JSON.stringify(corpus).replace(/</g,'\\u003c')};
const offlineResponse=(data,status=200)=>Promise.resolve(new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json'}}));
globalThis.fetch=(input)=>{
 const url=new URL(typeof input==='string'?input:input.url,'https://offline.invalid');
 if(url.pathname==='/api/status')return offlineResponse({configured:false,offline:true});
 if(url.pathname==='/api/textbook/search'){const q=url.searchParams.get('q')||'';return offlineResponse({results:searchTextbook(q,offlineCorpus.pages,{limit:5}),ocrNotice:offlineCorpus.meta.textStatus});}
 if(url.pathname==='/api/evidence'){const u=units.find(x=>x.id===url.searchParams.get('unit'));if(!u)return offlineResponse({error:'主题不存在'},404);return offlineResponse({title:u.title,pages:u.pages,pdfPages:u.pdfPages,ocrNotice:offlineCorpus.meta.textStatus,evidence:searchTextbook(u.title+' '+u.inputs.join(' '),offlineCorpus.pages,{range:u.pages,chapter:u.chapter,limit:3})});}
 return offlineResponse({error:'离线版不调用外部AI；请使用线上或本地服务器版本配置模型'},503);
};`;
let offlineApp=flatten(await read('src/app.js'));
offlineApp=offlineApp.replace(/function settings\(\)\{[\s\S]*?\nfunction help\(/,()=>`function settings(){showModal('<div class="eyebrow">OFFLINE EDITION</div><h2>单文件离线版</h2><p>卡牌探索、知识图谱、教材搜索、出处查看、理解挑战和存档都在本机运行，无需服务器。</p><p>本版向导提供本地资料查找与分级提示，不调用外部AI模型。真正的AI自由对话需要联网服务；在此HTML旁放置.env文件不会启用AI。</p><p>学习进度保存在当前浏览器中。移动、重命名文件或更换浏览器前，请先导出存档。</p><div class="dialog-actions"><button class="quiet-btn" data-action="export">导出学习存档</button><button class="quiet-btn" data-action="coverage">导出知识清单</button></div>');}
function help(`);
offlineApp=offlineApp.replaceAll('AI 接口尚未配置 · 当前为本地知识提示','单文件离线版 · 当前为本地知识提示');
const script='(()=>{\n'+[shared,retrieval,offlineApi,offlineApp].join('\n').replace(/<\/script/gi,'<\\/script')+'\n})();';
html=html.replace('<link rel="stylesheet" href="/style.css">',()=>'<style>'+css+'\n.offline-banner{padding:10px 20px;background:#e4eadb;color:#425742;font:12px/1.8 system-ui;text-align:center}</style>');
html=html.replace('<body>',()=>'<body><div class="offline-banner">离线版 · 游戏、教材检索和本地提示均可使用。联网 AI 请使用服务器版本。</div>');
html=html.replace('<script type="module" src="/app.js"></script>',()=>'<script>'+script+'</script>');
const output=resolve(process.argv[2]||'../理论炼金术-离线版.html');await writeFile(output,html,'utf8');console.log('Offline HTML: '+output);
