from pathlib import Path
p=Path(__file__).resolve().parents[1]/'src/app.js'
s=p.read_text(encoding='utf-8')
changes=[
 ("['explore','graph','atlas','review','progress']","['explore','graph','atlas','textbook','review','progress']"),
 ("['atlas','book','概念图鉴'],['review'","['atlas','book','概念图鉴'],['textbook','book','教材目录'],['review'"),
 ("page==='review'?review():archive()","page==='textbook'?textbook():page==='review'?review():archive()"),
 ('教材逐页核验待完成','教材目录与正文索引已接入'),
 ('<a class="source-link" href="${sourceUrl}" target="_blank" rel="noopener">教材定位：${chapters[u.chapter].label} · ${esc(u.section)} ↗</a>', '<button class="source-link" data-source="${u.id}">${pageLabel(u)} · 查看教材依据 ↗</button>'),
 ('教材定位：${esc(u.section)}<br>内容状态：','教材定位：${esc(u.section)}<br>${pageLabel(u)}<br>内容状态：'),
 ('<button class="primary" data-play="${u.id}">到工作台探索</button>', '<button class="primary" data-play="${u.id}">到工作台探索</button><button class="quiet-btn" data-source="${u.id}">查看教材依据</button>'),
 ('定位：${chapters[u.chapter].label} · ${esc(u.section)}</p>', '定位：${chapters[u.chapter].label} · ${esc(u.section)}<br>${pageLabel(u)}</p>'),
 ("if(d.detail){detail(d.detail);return;}","if(d.source){showEvidence(d.source);return;}if(d.outline){openOutline(d.outline);return;}if(d.detail){detail(d.detail);return;}"),
 ("case 'coverage':coverage();break;","case 'coverage':coverage();break;case 'book-search':searchBook();break;"),
 ("if(e.target.id==='chat-form'){e.preventDefault();sendChat($('#chat-input').value);}","if(e.target.id==='chat-form'){e.preventDefault();sendChat($('#chat-input').value);}if(e.target.id==='book-search-form'){e.preventDefault();searchBook();}"),
 ("'AI 理论向导 · 请对照教材核验'","'AI 理论向导 · 教材检索依据'"),
 ("['ID','章节','目录定位','学习主题','关系类型','学习摘要','检查问题','正确项','核验状态','来源']","['ID','章节','目录定位','学习主题','关系类型','书内页码','PDF页序','学习摘要','检查问题','正确项','核验状态','来源']"),
 ("u.section,u.title,u.relation,u.summary,u.question","u.section,u.title,u.relation,u.pages.join('-'),u.pdfPages.join('-'),u.summary,u.question"),
 ('当前版本整理了 ${units.length} 个学习主题，涉及导论、八章和结束语；这不等于已覆盖教材全部细目。目录结构已对照出版社公开目录，摘要、卡牌关系与题目均待教材逐页核验。未核验的内容不计为“已核验全书覆盖”。', '当前有 ${units.length} 个学习主题，均附对应章节和实际页码。${outline.length} 个目录细目均有关联任务，书内第1—266页已建立检索索引。目录覆盖、正文检索和具体知识点穷尽是不同指标；现有任务尚不能代替逐句阅读与教师审核。'),
]
for a,b in changes:
    if a not in s:raise RuntimeError('Cannot find UI replacement: '+a[:90])
    s=s.replace(a,b)
p.write_text(s,encoding='utf-8')
print('Updated',len(changes),'UI bindings')
