import {spawnSync,spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';

process.chdir(fileURLToPath(new URL('../',import.meta.url)));
const [major,minor]=process.versions.node.split('.').map(Number);
if(major<22||(major===22&&minor<13)){
 console.error('请安装 Node.js 22.13 或更新版本。当前版本：'+process.versions.node);
 process.exit(1);
}
console.log('正在构建理论炼金术…');
const build=spawnSync(process.execPath,['scripts/build.mjs'],{stdio:'inherit',windowsHide:true});
if(build.error||build.status!==0){
 console.error('构建未完成。请保留上方报错信息。');
 process.exit(build.status||1);
}
console.log(existsSync('.env')?'已找到 .env 配置，将由本地服务读取。':'未找到 .env，游戏仍可使用本地学习提示。');
console.log('正在启动服务，就绪后将自动打开默认浏览器。请保持此窗口运行；按 Ctrl+C 停止。');
const server=spawn(process.execPath,['--env-file-if-exists=.env','scripts/serve.mjs'],{stdio:['inherit','inherit','inherit','ipc'],windowsHide:true});
let opened=false;
server.on('message',async message=>{
 if(opened||message?.type!=='theory-alchemy-ready')return;
 opened=true;
 const url=message.url;
 try{
  const health=await fetch(new URL('/api/status',url),{signal:AbortSignal.timeout(5000)});
  if(!health.ok)throw new Error('not ready');
  const [command,args]=process.platform==='win32'?['rundll32.exe',['url.dll,FileProtocolHandler',url]]:process.platform==='darwin'?['open',[url]]:['xdg-open',[url]];
  const browser=spawn(command,args,{stdio:'ignore',windowsHide:true});
  browser.on('error',()=>console.log('未能自动打开浏览器，请手动打开：'+url));
  browser.on('exit',code=>console.log(code===0?'已请求默认浏览器打开：'+url:'请在浏览器手动打开：'+url));
 }catch{
  console.log('请在浏览器手动打开：'+url);
 }
});
server.on('error',()=>{console.error('本地服务启动失败。');process.exitCode=1;});
server.on('exit',(code,signal)=>{process.exitCode=signal?0:(code??1);});
