from pathlib import Path
import json,re,sys
pages=json.loads((Path(__file__).resolve().parents[1]/'research/pages.json').read_text(encoding='utf-8'))
start,end=map(int,sys.argv[1:3]);mode=sys.argv[3] if len(sys.argv)>3 else 'key'
for page in pages[start+11:end+12]:
    print('\n[书内页 '+str(page['pdfPage']-12)+']')
    if mode=='full':print(page['text']);continue
    lines=page['text'].splitlines()
    for i,line in enumerate(lines):
        line=line.strip()
        if re.match(r'^(?:[一二三四五六七八九十]+[、，]|[1-9][.・,、]|坚持|第一[，、]|第二[，、]|第三[，、]|第四[，、]|第五[，、]|第六[，、])',line):
            print((''.join(lines[i:i+3])).strip()[:155])
