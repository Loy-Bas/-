import http from 'node:http';
const worker=(await import('../dist/server/index.js')).default;
const port=Number(process.env.PORT||4173);
const host=process.env.HOST||'127.0.0.1';
const trustProxy=process.env.TRUST_PROXY==='1';
if(!Number.isInteger(port)||port<1||port>65535)throw new Error('PORT must be between 1 and 65535');
export const server=http.createServer(async(req,res)=>{try{
 const headers=new Headers();for(const [k,v] of Object.entries(req.headers))if(v&&!k.startsWith('oai-')&&!k.startsWith('cf-'))headers.set(k,Array.isArray(v)?v.join(','):v);
 // Direct clients must not impersonate Sites identities. The proxy option is
 // only enabled behind an operator-controlled ingress such as Render.
 const forwardedProto=trustProxy?String(req.headers['x-forwarded-proto']||'').split(',')[0].trim():'';
 const protocol=forwardedProto==='https'?'https':'http';
 const forwardedFor=trustProxy?String(req.headers['x-forwarded-for']||'').split(',').at(-1).trim():'';
 headers.set('cf-connecting-ip',forwardedFor||req.socket.remoteAddress||'local');
 const init={method:req.method,headers};if(!['GET','HEAD'].includes(req.method)){init.body=req;init.duplex='half';}
 const response=await worker.fetch(new Request(protocol+'://'+(req.headers.host||'127.0.0.1:'+port)+req.url,init),process.env);
 res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch{res.writeHead(500);res.end('Server error');}});
server.listen(port,host,()=>{
 console.log('理论炼金术 listening on http://'+host+':'+port);
 const browserHost=host==='0.0.0.0'?'127.0.0.1':host==='::'?'[::1]':host.includes(':')?'['+host+']':host;
 if(process.send)process.send({type:'theory-alchemy-ready',url:'http://'+browserHost+':'+server.address().port});
});
