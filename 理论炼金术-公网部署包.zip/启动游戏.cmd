@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto missing_node
node scripts\launch.mjs
if errorlevel 1 goto failed
exit /b 0
:missing_node
echo Node.js 22.13 or newer is required. Install it from https://nodejs.org/
:failed
echo.
echo Startup failed. Please keep the error message above.
pause
exit /b 1
