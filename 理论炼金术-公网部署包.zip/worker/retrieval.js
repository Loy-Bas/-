// Server-only OCR corpus. Browser receives bounded evidence snippets, not the PDF.
export function searchTextbook(question,pages,{chapter,range,limit=4}={}){
 const clean=s=>s.replace(/[^\p{L}\p{N}]/gu,'').toLowerCase();const q=clean(question);
 const tokens=[...new Set([...(q.match(/[a-z0-9]+/g)||[]),...Array.from({length:Math.max(0,q.length-1)},(_,i)=>q.slice(i,i+2)).filter(t=>/[\u4e00-\u9fff]/.test(t))])].filter(t=>!['的是','什么','怎么','如何','请问','解释','一下','这个','的关','联系','理论','社会','主义'].includes(t));
 let pool=range?pages.filter(p=>p.bookPage>=range[0]&&p.bookPage<=range[1]):pages;
 const ranked=pool.map(p=>{const text=clean(p.text),score=tokens.reduce((s,t)=>{const count=text.split(t).length-1;return s+(count?1+Math.log(1+count):0);},0)+(chapter===p.chapter?0.35:0)+(q.length>2&&text.includes(q)?15:0);return {page:p,score};}).filter(x=>x.score>0.35).sort((a,b)=>b.score-a.score||a.page.bookPage-b.page.bookPage);
 const threshold=ranked.length?ranked[0].score*0.45:Infinity;
 return ranked.filter(x=>x.score>=threshold).slice(0,limit).map(({page,score})=>{
 const lines=page.text.split('\n').map(x=>x.trim()).filter(Boolean);let best=0,bestScore=-1;for(let i=1;i<lines.length;i++){const chunk=clean(lines.slice(i,i+5).join('')),v=tokens.reduce((s,t)=>s+(chunk.includes(t)?1:0),0);if(v>bestScore){best=i;bestScore=v;}}
 const excerpt=lines.slice(Math.max(1,best-1),best+7).join('').slice(0,550);
 return {id:page.id,chapter:page.chapter,bookPage:page.bookPage,pdfPage:page.pdfPage,score:Math.round(score*100)/100,excerpt,title:'教材第'+page.bookPage+'页',section:'书内第'+page.bookPage+'页 / PDF第'+page.pdfPage+'页'};
 });
}
