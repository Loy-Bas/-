export const SAVE_KEY='theory-alchemy-v1';
export const DAY=86400000;
export function freshProgress(){return {version:1,chapter:1,discovered:{},learned:{},mastered:{},mistakes:{}};}
export function validateProgress(value,ids){
 if(!value||value.version!==1)throw new Error('存档版本不支持');
 const p=freshProgress();p.chapter=Number.isInteger(value.chapter)&&value.chapter>=0&&value.chapter<=9?value.chapter:1;
 for(const key of ['discovered','learned','mastered','mistakes']){const map=value[key];if(!map||typeof map!=='object'||Array.isArray(map))throw new Error('存档结构不正确');for(const [id,n] of Object.entries(map)){if(ids.has(id)&&Number.isFinite(n)&&n>=0&&n<1e14)p[key][id]=n;}}
 for(const id of Object.keys(p.learned))if(!p.discovered[id])delete p.learned[id];
 for(const id of Object.keys(p.mastered))if(!p.learned[id])delete p.mastered[id];return p;
}
export function matchesRecipe(labels,unit){return labels.length===unit.inputs.length&&new Set(labels).size===labels.length&&unit.inputs.every(x=>labels.includes(x));}
export function findRecipe(labels,units,chapter){return units.find(u=>u.chapter===chapter&&matchesRecipe(labels,u));}
export function applyAnswer(progress,id,correct,now=Date.now()){
 if(!correct){progress.mistakes[id]=(progress.mistakes[id]||0)+1;delete progress.mastered[id];return 'wrong';}
 if(!progress.discovered[id])progress.discovered[id]=now;
 if(!progress.learned[id]){progress.learned[id]=now;return 'learned';}
 if(now-progress.learned[id]>=DAY){progress.mastered[id]=now;return 'mastered';}return 'practice';
}
export function rankUnits(question,units,chapter){const q=question.toLowerCase();const terms=q.match(/[a-z0-9]+|[\u4e00-\u9fff]{2}/g)||[];return units.map(u=>({unit:u,score:(q.includes(u.title)?30:0)+terms.reduce((s,t)=>s+(u.title.includes(t)?5:u.summary.includes(t)?1:0),0)+(u.chapter===chapter?2:0)})).sort((a,b)=>b.score-a.score).slice(0,5);}
